<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{pscleaner}prestashop>pscleaner_e5a8af934462c05509c7de5f2f2c18a3'] = 'PrestaShop Cleaner';
$_MODULE['<{pscleaner}prestashop>pscleaner_4bcb9cc248b7f6c8dc7f5c323bde76de'] = 'Check and fix functional integrity constraints and remove default data';
$_MODULE['<{pscleaner}prestashop>pscleaner_752369f18aebeed9ae8384d8f1b5dc5e'] = 'Be really careful with this tool - There is no possible rollback!';
$_MODULE['<{pscleaner}prestashop>pscleaner_550b877b1a255ba717cfad4b82057731'] = 'The following queries successfully fixed broken data:';
$_MODULE['<{pscleaner}prestashop>pscleaner_14a7ab23d566b4505d0c711338c19a08'] = '%d line(s)';
$_MODULE['<{pscleaner}prestashop>pscleaner_d1ff3c9d57acd4283d2793a36737479e'] = 'Nothing that need to be fixed';
$_MODULE['<{pscleaner}prestashop>pscleaner_11083f3c322af3f9f5d5d5b407a264ec'] = 'The following queries successfully cleaned your database';
$_MODULE['<{pscleaner}prestashop>pscleaner_098c3581a731f08d24311bbf515adbbb'] = 'Nothing that need to be cleaned';
$_MODULE['<{pscleaner}prestashop>pscleaner_1bb7c5eb8682aeada82c407b40ec09c8'] = 'Catalog truncated';
$_MODULE['<{pscleaner}prestashop>pscleaner_ed6ecb7169d5476ef5251524bb17552a'] = 'Orders and customers truncated';
$_MODULE['<{pscleaner}prestashop>pscleaner_43364f357f96e8b70be4a44d44196807'] = 'Please read the disclaimer and click "Yes" above';
$_MODULE['<{pscleaner}prestashop>pscleaner_6c69628e1d57fa6e39162b039a82133b'] = 'Are you sure that you want to delete all catalog data?';
$_MODULE['<{pscleaner}prestashop>pscleaner_6a68264705f23c8e3d505fd2c93a87ba'] = 'Are you sure that you want to delete all sales data?';
$_MODULE['<{pscleaner}prestashop>pscleaner_c32516babc5b6c47eb8ce1bfc223253c'] = 'Catalog';
$_MODULE['<{pscleaner}prestashop>pscleaner_da69e50b7440e12fe63287904819eaa3'] = 'I understand that all the catalog data will be removed without possible rollback: products, features, categories, tags, images, prices, attachments, scenes, stocks, attribute groups and values, manufacturers, suppliers...';
$_MODULE['<{pscleaner}prestashop>pscleaner_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{pscleaner}prestashop>pscleaner_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{pscleaner}prestashop>pscleaner_b2d7c99e984831bd36221baf34e9c26e'] = 'Delete catalog';
$_MODULE['<{pscleaner}prestashop>pscleaner_3300d0bf086fa38cf593fe4feff351f1'] = 'Orders and customers';
$_MODULE['<{pscleaner}prestashop>pscleaner_a01f9a9a340c3c68a2dc4663f46d8637'] = 'I understand that all the orders and customers will be removed without possible rollback: customers, carts, orders, connections, guests, messages, stats...';
$_MODULE['<{pscleaner}prestashop>pscleaner_17ca7f22baf84821b6b73462c96fb1e3'] = 'Delete orders & customers';
$_MODULE['<{pscleaner}prestashop>pscleaner_3535aa31bd9005bde626ad4312b67d6b'] = 'Functional integrity constraints';
$_MODULE['<{pscleaner}prestashop>pscleaner_e84c6595e849214a70b35ed8f95d7d16'] = 'Check & fix';
$_MODULE['<{pscleaner}prestashop>pscleaner_ccc27439e3e08c444690af3bed668e2d'] = 'Database cleaning';
$_MODULE['<{pscleaner}prestashop>pscleaner_39707b9cfefe433d64f695623d2d3fd7'] = 'Clean & Optimize';


return $_MODULE;
