<?php
global $_MODULE;
$_MODULE = array();
$_MODULE['<{outvio}prestashop>outvio_'.md5("Please, go to Outvio application to configure your settings.")] = 'Por favor, ve a Outvio para configurar tus preferencias. ';
