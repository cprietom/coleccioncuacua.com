<?php
/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * You must not modify, adapt or create derivative works of this source code
 *
 *  @author    Outvio OU
 *  @copyright 2017-2018 Outvio OU
 *  @license   Outvio OU
 */

if (!defined('_PS_VERSION_')) {
        exit;
}

class Outvio extends Module
{

    private $api_payment_methods = array();
    private $api_order_status = array();

    private $payment_modules = null;

    /**
     * @var array
     */
    private $api_statuses = array();

    public function __construct()
    {
        $this->name = 'outvio';
        $this->tab = 'shipping_logistics';
        $this->version = '1.3.4';
        $this->author = 'Outvio';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.5', 'max' => '1.7.99');
        $this->bootstrap = true;

        $this->module_key = '8b362dead2556faa77e7e7d8fc1c28ee';

        parent::__construct();

        $this->displayName = $this->l('Outvio');
        $this->description = $this->l('Outvio shipping integration.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        if (!Configuration::get('OUTVIO_NAME')) {
            $this->warning = $this->l('No name provided');
        }

        $this->api_payment_methods = array(
            'credit_card' => array(
                'title' => $this->l('Credit Card'),
                'name' => 'credit_card',
            ),
            'bank_transfer' => array(
                'title' => $this->l('Bank transfer'),
                'name' => 'bank_transfer',
            ),
            'c_o_d' => array(
                'title' => $this->l('Cash on delivery'),
                'name' => 'c_o_d',
            ),
        );

        $this->api_order_status = array(
            'paid' => array(
                'title' => $this->l('Paid'),
                'name' => 'paid'
            ),
            'not_paid' => array(
                'title' => $this->l('Not Paid'),
                'name' => 'not_paid'
            )
        );

        $this->api_statuses = array(
            array(
                'alias' => 'processing',
                'name' => 'Processing',
                'desc' => 'When entering in shipping queue change status to ("Processing")'
            ),
            array(
                'alias' => 'shipped',
                'name' => 'Shipped',
                'desc' => 'When entering the tracking tab, after label is printed, change status to ("Shipped")'
            ),
            array(
                'alias' => 'delivered',
                'name' => 'Delivered',
                'desc' => 'When being delivered, change status to ("Delivered")'
            ),
            array(
                'alias' => 'returned',
                'name' => 'Returned',
                'desc' => 'When being returned by client, change status to ("Returned")'
            ),
            array(
                'alias' => 'refunded',
                'name' => 'Refunded',
                'desc' => 'When return is refunded change status to ("Refunded")'
            )
        );
    }

    public function getContent()
    {
        $tpl = $this->context->smarty->createTemplate(_PS_MODULE_DIR_.$this->name.'/views/templates/admin/outvio-hello.tpl');
        $tpl->assign(array('message' => $this->l('Please, go to Outvio application to configure your settings.')));
        return $tpl->fetch();
    }

    public function install()
    {
        Configuration::updateValue('OUTVIO_API_MODE', 0);
        Configuration::deleteByName('OUTVIO_SEND_STATUS');
        Configuration::updateValue('OUTVIO_API_KEY', '');
        return parent::install() && $this->registerHook('actionValidateOrder') && $this->registerHook('actionOrderStatusPostUpdate');
    }

    public function uninstall()
    {
        Configuration::deleteByName('OUTVIO_SEND_STATUS');
        Configuration::deleteByName('OUTVIO_API_MODE');
        Configuration::deleteByName('OUTVIO_API_KEY');
            return parent::uninstall();
    }

    public function check($id_order)
    {
        $params = $this->getOrderInfo($id_order);
        $order = new Order($id_order);
        if (Configuration::get('OUTVIO_SEND_STATUS') !== false and !in_array($order->current_state, $this->getSendSatatus())) {
            die('false by send status');
        }

        $params['OUTVIO_PARAMS']=array(
         'API_KEY' => Configuration::get('OUTVIO_API_KEY'),
         'CMS_ID' => 'prestashop',
         'CMS_VERSION' => _PS_VERSION_
        );

        $requestContent = json_encode($params);

        $apiResponse = '';

        if (Configuration::get('OUTVIO_DEBUG_MODE')) {
            $fileName = $id_order.'-resend-'.date('H-m-d_His').'.txt';
            $handle = fopen($this->getDebugFolder().DIRECTORY_SEPARATOR.$fileName, 'w');
            fwrite($handle, "Endpoint:\n");
            fwrite($handle, $this->getApiUrl());
            fwrite($handle, "\n\n");
            fwrite($handle, "Request:\n");
            fwrite($handle, $requestContent);
            fwrite($handle, "\n\n");
            fwrite($handle, "Response:\n");
            fwrite($handle, $apiResponse);
            fclose($handle);
        }

        $tpl = $this->context->smarty->createTemplate(_PS_MODULE_DIR_.$this->name.'/views/templates/admin/outvio-check.tpl');
        $tpl->assign(array(
            'endpoint' => $this->getApiUrl(),
            'request' => $requestContent,
            'response' => $apiResponse,
        ));
        return $tpl->fetch();
    }

    /**
     * Get order info
     * @param int $id_order
     * @return array
     */
    private function getOrderInfo($id_order)
    {
        $order = new Order((int)$id_order);
        if (!Validate::isloadedObject($order)) {
            return array();
        }

        $currency = new Currency($order->id_currency);

        $carrier = new Carrier($order->id_carrier, $order->id_lang);

        $address_invoice = new Address($order->id_address_invoice, $order->id_lang);
        $invoice_country_code = Tools::strtoupper(Country::getIsoById($address_invoice->id_country));
        //$this->_debug($address_invoice);
        $address_delivery = new Address($order->id_address_delivery, $order->id_lang);
        $delivery_country_code = Tools::strtoupper(Country::getIsoById($address_delivery->id_country));

        $client_invoice_phone = trim($address_invoice->phone_mobile);
        if ($client_invoice_phone == '') {
            $client_invoice_phone = $address_invoice->phone;
        }

        $client_delivery_phone = trim($address_delivery->phone_mobile);
        if ($client_delivery_phone == '') {
            $client_delivery_phone = $address_delivery->phone;
        }

        $state1 = new State($address_invoice->id_state, $order->id_lang);
        $state2 = new State($address_delivery->id_state, $order->id_lang);

        $customer = new Customer($order->id_customer);

        $order->setInvoice(true);
        $order->setDelivery();

        $invoice = new OrderInvoice($order->invoice_number);

        $order_status = '';
        $payment_method = '';

        if ($order->module) {
            foreach ($this->api_payment_methods as $k => $item) {
                $key = $this->name.'_'.$k;
                $val = Configuration::get(Tools::strtoupper($key));
                if ($val) {
                    $values = explode('|', $val);
                    if (in_array($order->module, $values)) {
                        $payment_method = $item['title'];
                        break;
                    }
                }
            }
        }

        foreach ($this->api_order_status as $k => $item) {
            $key = $this->name.'_'.$k;
            $val = Configuration::get(Tools::strtoupper($key));
            if ($val) {
                $values = explode('|', $val);
                if (in_array($order->current_state, $values)) {
                    $order_status = $item['title'];
                    break;
                }
            }
        }

        if (empty($address_invoice->address1)) {
            $invoice_address = $address_delivery->address1 . ($address_delivery->address2 ? ' - '.$address_delivery->address2 : '');
        } else {
            $invoice_address = $address_invoice->address1 . ($address_invoice->address2 ? ' - '.$address_invoice->address2 : '');
        }

        $delivery_address = $address_delivery->address1 . ($address_delivery->address2 ? ' - '.$address_delivery->address2 : '');

        $result = array(
            'id' => (int) $order->id,
            'dateTime' => date('Y-m-d\TH:i:s.000\Z', strtotime($order->date_add)),
            'payment' => array(
                'status' => $order_status,
                'method' => $payment_method
            ),
            'total' => Tools::ps_round($order->total_paid_tax_incl, 2),
            'currency' => $currency->iso_code,
            'tax' => ($order->getTotalProductsWithTaxes() - $order->getTotalProductsWithoutTaxes()),
            'products' => array(),
            'invoicingCompany' => (empty($address_invoice->company) ? $address_delivery->company : $address_invoice->company),
            'invoicingCompanyTaxId' => (empty($address_invoice->vat_number) ? $address_delivery->vat_number : $address_invoice->vat_number),
            'client' => array(
                'invoicing' => array(
                    "name" => (
                        empty(trim($address_invoice->firstname.' '.$address_invoice->lastname))
                        ? trim($address_delivery->firstname.' '.$address_delivery->lastname)
                        : trim($address_invoice->firstname.' '.$address_invoice->lastname)
                    ),
                    "postcode" => (empty($address_invoice->postcode) ? $address_delivery->postcode : $address_invoice->postcode),
                    "countryCode" => (empty($invoice_country_code) ? $delivery_country_code : $invoice_country_code),
                    "state" => ( empty($state1->name) ? $state2->name : $state1->name ),
                    "city" => (empty($address_invoice->city) ? $address_delivery->city : $address_invoice->city),
                    "address" => $invoice_address,
                    "email" => $customer->email,
                    "phone" => (empty($client_invoice_phone) ? $client_delivery_phone : $client_invoice_phone)
                ),
                'delivery' => array(
                    "name" => trim($address_delivery->firstname.' '.$address_delivery->lastname),
                    "postcode" => $address_delivery->postcode,
                    "countryCode" => $delivery_country_code,
                    "state" => $state2->name,
                    "city" => $address_delivery->city,
                    "address" => $delivery_address,
                    "email" => $customer->email,
                    "phone" => $client_delivery_phone,
                    // "comment" => $address_delivery->other,
                    // get firts message from order created by customer
                    "comment" => (string)Db::getInstance()->getValue(
                        "SELECT message FROM "._DB_PREFIX_."message
                            WHERE
                                id_order=".(int)$order->id."
                                AND id_customer=".(int)$order->id_customer."
                            ORDER BY
                                id_message ASC"
                    )
                ),
            ),
            'shipping' => array(
                'price' => (float) Tools::ps_round($order->total_shipping_tax_incl, 2),
                'method' => $carrier->name,
            ),
            'invoiceUrl' => $this->context->link->getPageLink('pdf-invoice', null, null, array('id_order'=>$order->id,'secure_key'=>$order->secure_key)),
            'invoiceNumber' => $invoice->getInvoiceNumberFormatted($order->id_lang),
            'api_url' => $this->context->link->getModuleLink($this->name, 'api', array(), true)
        );

        $protocol_link = (Configuration::get('PS_SSL_ENABLED') || Tools::usingSecureMode()) ? 'https://' : 'http://';
        $base_dir__ssl = $protocol_link.Tools::getShopDomainSsl().__PS_BASE_URI__;

        $products = $order->getProducts();
        foreach ($products as $product) {
            $p = new Product($product['product_id'], false, $order->id_lang);
            //$c = new Category($p->id_category_default, $order->id_lang);
            $price = (float) Tools::ps_round((float) $product['price'] + (float)(($product['tax_rate'] / 100) * $product['price']), 2);
            $discountedPrice = (float) Tools::ps_round($product['unit_price_tax_incl'], 2);

            $result['products'][] = array(
                "id" => $p->id,
                "name" => (string) $p->name,
                "price" => $price,
                "discountPrice" => $discountedPrice < $price ? $discountedPrice : '',
                "vat" => (float) $product['tax_rate'],
                "vatAmount" => ( (float) $product['unit_price_tax_incl'] - (float) $product['unit_price_tax_excl'] ),
                "quantity" => (int) $product['product_quantity'],
                "barcode" => "",
                "sku" => (string) $product['product_reference'],
                "variant" => $this->getProductVariantName($p->id, $product['product_attribute_id'], $order->id_lang),
                "type" => $this->getHSCode($p->id, $order->id_lang),
                "weight" => (float) Tools::ps_round($product['weight'], 2),
                "pictureUrl" => ( $product['image'] ? $base_dir__ssl.'img/p/' . $product['image']->getExistingImgPath(). '.'.$product['image']->image_format : $base_dir__ssl.'img/p/'.$this->context->language->iso_code.'.jpg')
            );
        }

        foreach ($result as &$data) {
            if (is_array($data)) {
                foreach ($data as $k => $v) {
                    if (is_array($v)) {
                        foreach ($v as $j => $p) {
                            if (is_null($p)) {
                                $data[$k][$j] = '';
                            }
                        }
                    } elseif (is_null($v)) {
                        $data[$k] = '';
                    }
                }
            } elseif (is_null($data)) {
                $data = '';
            }
        }

        return $result;
    }

    /**
     * @param int $id_product
     * @param int $id_lang
     * @return array
     */
    private function getHSCode($id_product, $id_lang)
    {
        $res = Db::getInstance()->executeS("SELECT DISTINCT t.name FROM "._DB_PREFIX_."product_tag AS pt
                                                                                LEFT JOIN "._DB_PREFIX_."tag AS t ON (t.id_tag=pt.id_tag AND t.id_lang=".(int)$id_lang.")
                                                                                WHERE (t.name LIKE 'HS %' OR t.name LIKE 'HS%') AND pt.id_product=".(int)$id_product.
                                                                                " ORDER BY t.name ASC");
        $codes = array();
        foreach ($res as $row) {
            $codes[] = $row['name'];
        }
        return $codes;
    }

    /**
     * Gets the name of a given product, in the given lang
     *
     * @since 1.5.0
     * @param int $id_product
     * @param int $id_product_attribute Optional
     * @param int $id_lang Optional
     * @return string
     */
    private function getProductVariantName($id_product, $id_product_attribute = null, $id_lang = null)
    {
        // use the lang in the context if $id_lang is not defined
        if (!$id_lang) {
            $id_lang = (int)Context::getContext()->language->id;
        }

        // creates the query object
        $query = new DbQuery();

        // selects different names, if it is a combination
        if ($id_product_attribute) {
            //$query->select('GROUP_CONCAT(DISTINCT agl.`name`, \' - \', al.name SEPARATOR \', \') as name');
            $query->select('GROUP_CONCAT(DISTINCT al.name SEPARATOR \' \') as name');
        } else {
            $query->select('DISTINCT pl.name as name');
        }

        // adds joins & where clauses for combinations
        if ($id_product_attribute) {
            $query->from('product_attribute', 'pa');
            $query->join(Shop::addSqlAssociation('product_attribute', 'pa'));
            $query->innerJoin('product_lang', 'pl', 'pl.id_product = pa.id_product AND pl.id_lang = '.(int)$id_lang.Shop::addSqlRestrictionOnLang('pl'));
            $query->leftJoin('product_attribute_combination', 'pac', 'pac.id_product_attribute = pa.id_product_attribute');
            $query->leftJoin('attribute', 'atr', 'atr.id_attribute = pac.id_attribute');
            $query->leftJoin('attribute_lang', 'al', 'al.id_attribute = atr.id_attribute AND al.id_lang = '.(int)$id_lang);
            $query->leftJoin('attribute_group_lang', 'agl', 'agl.id_attribute_group = atr.id_attribute_group AND agl.id_lang = '.(int)$id_lang);
            $query->where('pa.id_product = '.(int)$id_product.' AND pa.id_product_attribute = '.(int)$id_product_attribute);
        } else {
            // or just adds a 'where' clause for a simple product

            $query->from('product_lang', 'pl');
            $query->where('pl.id_product = '.(int)$id_product);
            $query->where('pl.id_lang = '.(int)$id_lang.Shop::addSqlRestrictionOnLang('pl'));
        }

        return Db::getInstance()->getValue($query);
    }

    public function hookActionValidateOrder($params)
    {
        $orderStatus = $params['orderStatus'];
        $params = $this->getOrderInfo($params['order']->id);

        // if ($params === false)
        if (Configuration::get('OUTVIO_SEND_STATUS') !== false and !in_array($orderStatus->id, $this->getSendSatatus())) {
            return true;
        }


        if (!empty($params) and empty($params['payment']['status'])) {
            //$params['payment']['status'] = $orderStatus->name;
            foreach ($this->api_order_status as $k => $item) {
                $key = $this->name.'_'.$k;
                $val = Configuration::get(Tools::strtoupper($key));
                if ($val) {
                    $values = explode('|', $val);
                    if (in_array($orderStatus->id, $values)) {
                        $params['payment']['status'] = $item['title'];
                        break;
                    }
                }
            }
        }

        $this->_request($params);
    }

    public function hookActionOrderStatusPostUpdate($params)
    {
        if (Tools::getIsset(Tools::getValue('disable_hook_update_status_outvio', '')) && Tools::getValue('disable_hook_update_status_outvio', '') == true) {
            return true;
        }

        $orderStatus = $params['newOrderStatus'];
        $params = $this->getOrderInfo($params['id_order']);

        if (empty($params) || !is_array($params)) {
            return true;
        }

        // check (Send orders to Outvio with the following statuses)
        if (Configuration::get('OUTVIO_SEND_STATUS') !== false and !in_array($orderStatus->id, $this->getSendSatatus())) {
            return true;
        }

        if (!empty($params) and empty($params['payment']['status'])) {
            foreach ($this->api_order_status as $k => $item) {
                $key = $this->name.'_'.$k;
                $val = Configuration::get(Tools::strtoupper($key));
                if ($val) {
                    $values = explode('|', $val);
                    if (in_array($orderStatus->id, $values)) {
                        $params['payment']['status'] = $item['title'];
                        break;
                    }
                }
            }
        }

        $this->_request($params);
    }

    /**
     * Send request method
     * @param array $params
     */
    private function _request(array $params)
    {
        $params['OUTVIO_PARAMS']=array(
         'API_KEY' => Configuration::get('OUTVIO_API_KEY'),
         'CMS_ID' => 'prestashop',
         'CMS_VERSION' => _PS_VERSION_
        );

        $requestContent = json_encode($params);

        $apiResponse = '';

        /* send order data */
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->getApiUrl());
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $requestContent);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json'
            ));
            $apiResponse = curl_exec($ch);
        } else {
            $API_OPTS = array(
                'http' => array(
                    'method' => "POST",
                    'header' => 'Content-Type: application/json',
                    'content' => $requestContent
                )
            );
            $API_CONTEXT = stream_context_create($API_OPTS);
            $apiResponse = Tools::file_get_contents($this->getApiUrl(), false, $API_CONTEXT);
        }
        /* end send order data */

        if (Configuration::get('OUTVIO_DEBUG_MODE')) {
            $fileName = $params['id'].'-'.Tools::passwdGen(10).'.txt';
            $handle = fopen($this->getDebugFolder().DIRECTORY_SEPARATOR.$fileName, 'w');
            fwrite($handle, "Endpoint:\n");
            fwrite($handle, $this->getApiUrl());
            fwrite($handle, "\n\n");
            fwrite($handle, "Request:\n");
            fwrite($handle, $requestContent);
            fwrite($handle, "\n\n");
            fwrite($handle, "Response:\n");
            fwrite($handle, $apiResponse);
            fclose($handle);
        }
    }

    public function getApiStatusList()
    {
        return array_map(function ($a) {
            return $a['alias'];
        }, $this->api_statuses);
    }

    private function getDebugFolder()
    {
        $dir = dirname(__FILE__);
        if (!file_exists($dir.DIRECTORY_SEPARATOR.'logs')) {
            mkdir($dir.DIRECTORY_SEPARATOR.'logs');
            $f = fopen($dir.DIRECTORY_SEPARATOR.'logs'.DIRECTORY_SEPARATOR.'index.php', 'w');
            fwrite($f, Tools::getDefaultIndexContent());
            fclose($f);
        }
        return $dir.DIRECTORY_SEPARATOR.'logs';
    }

    private function _debug($var, $dump = false)
    {
        $tpl = $this->context->smarty->createTemplate(_PS_MODULE_DIR_.$this->name.'/views/templates/admin/outvio-debug.tpl');
        $tpl->assign(array(
            'dump' => $dump,
            'var' => $var,
        ));
        return $tpl->fetch();
    }

    public function getApiUrl()
    {
        if (Configuration::get('OUTVIO_API_MODE')) {
            return 'http://dev.api.outvio.com/order';
        }

        return 'https://api.outvio.com/order';
    }

    private function getSendSatatus()
    {
        if (Configuration::get('OUTVIO_SEND_STATUS') === false) {
            return array();
        }

        return explode('|', Configuration::get('OUTVIO_SEND_STATUS'));
    }
}
