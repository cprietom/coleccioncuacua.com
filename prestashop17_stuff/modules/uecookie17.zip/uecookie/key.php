<?PHP 
$this->mkey="freelicense";
?>