$().ready(function () {
    tinySetup();
});