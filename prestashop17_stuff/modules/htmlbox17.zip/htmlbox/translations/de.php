<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{htmlbox}prestashop>htmlbox_66e0c17dd87ad977b7d3e3e2cbbc44a7'] = 'HTMLbox';
$_MODULE['<{htmlbox}prestashop>htmlbox_2a5b55f8f0ea547b659506ee561a1f1d'] = 'Mit diesem Modul können Sie den HTML/JavaScript/CSS  Code wo immer Sie wollen.';
$_MODULE['<{htmlbox}prestashop>htmlbox_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Bestätigung';
$_MODULE['<{htmlbox}prestashop>htmlbox_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{htmlbox}prestashop>htmlbox_83fc76a8bceb3526eda29c20add790b6'] = 'HTMLbox konfiguration';
$_MODULE['<{htmlbox}prestashop>htmlbox_54108d6986ee41288fa9d5b4fdec420c'] = 'Wo angezeigt HTMLbox?';
$_MODULE['<{htmlbox}prestashop>htmlbox_01090c774c1734d594584ec91fb7ab47'] = 'Geben Sie den HTML/js/css Code hier ein.';
$_MODULE['<{htmlbox}prestashop>htmlbox_9daf1fb753b42c3cdc8f1d01669cd6d8'] = 'Einstellungen speichern';
